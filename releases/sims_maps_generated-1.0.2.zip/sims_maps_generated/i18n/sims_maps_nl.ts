<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="nl" sourcelanguage="">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../edit_layout_dialog.ui" line="14"/>
        <source>Edit SIMS Layout</source>
        <translation>SIMS Layout wijzigen</translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="27"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="34"/>
        <source>Map content, Location, Date</source>
        <translation>Kaartinhoud, lokatie, datum</translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="41"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="48"/>
        <source>DD MMMM YYYY</source>
        <translation>DD MMMM JJJJ</translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="55"/>
        <source>Appeal code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="62"/>
        <source>MDRNL0XX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="69"/>
        <source>Glide number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_layout_dialog.ui" line="76"/>
        <source>NL-2017000001-GIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../create_layout_dialog.ui" line="14"/>
        <source>Create SIMS Layout</source>
        <translation>SIMS Layout aanmaken</translation>
    </message>
    <message>
        <location filename="../create_layout_dialog.ui" line="27"/>
        <source>Template</source>
        <translation>Sjabloon</translation>
    </message>
    <message>
        <location filename="../create_layout_dialog.ui" line="46"/>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../create_layout_dialog.ui" line="56"/>
        <source>NS logo</source>
        <translation>NS-logo</translation>
    </message>
    <message>
        <location filename="../create_layout_dialog.ui" line="66"/>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <location filename="../create_layout_dialog.ui" line="84"/>
        <source>labelImagePreview</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SimsMaps</name>
    <message>
        <location filename="../__init__.py" line="92"/>
        <source>initGui</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../__init__.py" line="101"/>
        <source>Create SIMS Layout</source>
        <translation>SIMS Layout aanmaken</translation>
    </message>
    <message>
        <location filename="../__init__.py" line="511"/>
        <source>Edit SIMS Layout</source>
        <translation>SIMS Layout wijzigen</translation>
    </message>
</context>
</TS>
